#�@�K�v�ȃp�b�P�[�W�̃C���X�g�[��
# install.packages("reshape")
# install.packages("RCurl")
# install.packages("scales")
# install.packages("nnet")
# install.packages("Ecdat")
# install.packages("devtools")

### 1.Read Data
#�A�f�[�^"Catsup"�̓ǂݍ���
library(Ecdat)
library(nnet)
library(scales)
data("Catsup")
head(Catsup,20)
set.seed(1)
tr = sample(1:nrow(Catsup),2000)
### 2.Nnet
set.seed(1)
n.net <- nnet(choice ~ .-id,data=Catsup[tr,],
              size=5,decay=0.006,linout=T,skip=T,
              maxit=3000,Hess=T)
n.net
summary(n.net)

#�B���f������
# 3.����
pred = predict(n.net,newdata=Catsup[-tr,],type="class")
tab =table(Catsup$choice[-tr],as.factor(pred))
tab2 = tab
tab2[,1]=tab[,3]
tab2[,3]=tab[,1]
colnames(tab2)=colnames(tab2)[c(3,2,1,4)]
tab2
cat(paste(
  "Accuracy:",
  round((sum(diag(tab2)))  /  sum(tab2),3)
 ) )


#�C���ʂ̉���
## 4.����

library(devtools)
source_url('https://gist.githubusercontent.com/fawda123/5086859/raw/cc1544804d5027d82b70e74b83b3941cd2184354/nnet_plot_fun.r')


par(mfrow=c(1,1))
plot.nnet(n.net)
# Color
par(mar=numeric(4),family='serif')
plot.nnet(n.net,pos.col='darkgreen',neg.col='darkblue',alpha.val=1,circle.col='brown')



#### ���x���グ��
set.seed(1)
n.net2 <- nnet(choice ~ .-id,data=Catsup[tr,],
              size=20,decay=0.006,linout=T,skip=T,
              maxit=3000,Hess=T)
pred = predict(n.net2,newdata=Catsup[-tr,],type="class")
tab =table(Catsup$choice[-tr],as.factor(pred))
tab2 = tab
tab2[,1]=tab[,3]
tab2[,3]=tab[,1]
colnames(tab2)=colnames(tab2)[c(3,2,1,4)]
tab2
cat(paste(
  "Accuracy:",
  round((sum(diag(tab2)))  /  sum(tab2),3)
))
