#�@�K�v�ȃp�b�P�[�W�̃C���X�g�[��
# Installation
# install.packages("drat", repos="https://cran.rstudio.com")
# drat:::addRepo("dmlc")
# install.packages("mxnet")
library(mxnet)
library(Ecdat)
# train<-read.csv('https://github.com/ozt-ca/tjo.hatenablog.samples/raw/master/r_samples/public_lib/jp/mnist_reproduced/short_prac_train.csv')
# test<-read.csv('https://github.com/ozt-ca/tjo.hatenablog.samples/raw/master/r_samples/public_lib/jp/mnist_reproduced/short_prac_test.csv')
# train<-data.matrix(train)
# test<-data.matrix(test)
# train.x<-train[,-1]
# train.y<-train[,1]
# train.x<-t(train.x/255)
# test_org<-test
# test<-test[,-1]
# test<-t(test/255)
# table(train.y)
# 
# train<-read.csv('https://github.com/ozt-ca/tjo.hatenablog.samples/raw/master/r_samples/public_lib/jp/mnist_reproduced/short_prac_train.csv')
# test<-read.csv('https://github.com/ozt-ca/tjo.hatenablog.samples/raw/master/r_samples/public_lib/jp/mnist_reproduced/short_prac_test.csv')

##

#�A�f�[�^"Catsup"�̓ǂݍ���
# 1. read data
data("Catsup")
set.seed(1)
tr = sample(1:nrow(Catsup),2000)
train<-data.matrix(Catsup[tr,])

test<-data.matrix(Catsup[-tr,])
train.x<-train[,-c(1,ncol(train))]
train.y<-as.factor(train[,ncol(train)])
train.x<-t(train.x)
test_org<-test
test<-test[,-c(1,ncol(test))]
test<-t(test)
table(train.y)


#�B���f������
# 2. build CNN
data <- mx.symbol.Variable("data")
fc1 <- mx.symbol.FullyConnected(data, name="fc1", num_hidden=128)
act1 <- mx.symbol.Activation(fc1, name="relu1", act_type="relu")
fc2 <- mx.symbol.FullyConnected(act1, name="fc2", num_hidden=64)
act2 <- mx.symbol.Activation(fc2, name="relu2", act_type="relu")
fc3 <- mx.symbol.FullyConnected(act2, name="fc3", num_hidden=6)
softmax <- mx.symbol.SoftmaxOutput(fc3, name="sm")
devices <- mx.cpu()
mx.set.seed(0)

model <- mx.model.FeedForward.create(softmax, X=train.x, y=train.y,
                                                                             ctx=devices, num.round=200, array.batch.size=100,
                                                                             learning.rate=0.07, momentum=0.9,  eval.metric=mx.metric.accuracy,
                                                                             initializer=mx.init.uniform(0.07),
                                                                             epoch.end.callback=mx.callback.log.train.metric(100))
graph.viz(model$symbol$as.json())
#�C�\���]��
## 3. Predict 
preds <- predict(model,test, ctx=devices)
dim(preds)
pred.label <- max.col(t(preds)) - 1
table(pred.label)
head(pred.label)
table(test_org[,ncol(test_org)],pred.label)
sum(diag(table(test_org[,ncol(test_org)],pred.label)))/(nrow(Catsup)-2000)  ## accuracy for test data
 
