## �@�p�b�P�[�W�̃C���X�g�[��
 install.packages(c("rpart","rpart.plot","randomForest","gbm"))


## �A�f�[�^�t�@�C���̓ǂݍ���
## 1 Read Simulate Data

Dec.Data = read.table("dec_data.csv",header=TRUE,sep=",")


## �B����؂̕���
############# 2 Classic Decison tree (discrete)
set.seed(1)
TestD = sample(1:500,50)
Data.Tr = Dec.Data[-TestD,]
Data.T  = Dec.Data[TestD,]
head(Data.Tr)

library(rpart)      ### decision tree

result = rpart(Buy ~.-ID - Purchase ,data = Data.Tr, method="class")
result
library(rpart.plot) ### plot graph
prp(result, type=3, extra=102,nn=TRUE, fallen.leaves=TRUE,faclen=0,varlen=0,shadow.col ="grey" )

yhat.result = predict(result,Data.T,type="class")
yhat.table = table(Data.T$Buy,yhat.result)
print("==== Class")
print(yhat.table)
print(paste("estimate of misclassification error:",(yhat.table[1,2]+yhat.table[2,1])/nrow(Data.T) ))


## �C��A�؂̕���
##### 3 Continious Data
set.seed(1)
result.C = rpart(Purchase~.-ID ,data=Data.Tr,method="anova")
result.C
prp(result.C, type=3,nn=TRUE, fallen.leaves=TRUE,faclen=0,varlen=0,shadow.col ="grey" )

yhat.c = predict(result.C, newdata= Data.T)

(rmse.s = sqrt(sum((yhat.c-Data.T[,3])^2)/50) )   ### RMSE


## optional (prune)

plotcp(result.C)

result.C1 = prune(result.C,cp = 0.02)
prp(result.C1, type=3,nn=TRUE, fallen.leaves=TRUE,faclen=0,varlen=0,shadow.col ="grey" )



## �D�����_���t�H���X�g
##### 4 randomForest

library(randomForest)

set.seed(1)

bag.data = randomForest(Purchase~.-ID,data=Data.Tr,mtry=5,importance=TRUE) ## Bagging

for.data = randomForest(Purchase~.-ID,data=Data.Tr,mtry=4,importance=TRUE) ## RF

yhat.bag = predict(bag.data,newdata=Data.T)

yhat.for = predict(for.data,newdata=Data.T)


plot(sqrt(for.data$mse),type="l",main="RMSE(Red=Bagging,Blue=Random Forest)",col="blue",
     ylim=c(min(sqrt(for.data$mse),sqrt(bag.data$mse)),max(sqrt(for.data$mse),sqrt(bag.data$mse)) ),
     ylab="RMSE",xlab="ntrees"
)
lines(sqrt(bag.data$mse),col="red")

importance(bag.data)
importance(for.data)

varImpPlot(bag.data)
varImpPlot(for.data)



## �E�u�[�X�e�B���O
#### 5 Boosting

library(gbm)

##### package�X�V�ɂ��ǉ�
library(dplyr)
Data.Tr = Data.Tr %>% mutate_if(is.character,as.factor)
#######

set.seed(1)
result.boost = gbm(Purchase~.-ID,data=Data.Tr,distribution = "gaussian",n.trees = 35000, interaction.depth=3)

yhat.boost = predict(result.boost,newdata=Data.T,n.trees = 35000)

rmse.1 = round(sqrt(sum((yhat.c-Data.T[,3])^2)/50)   ,3)
rmse.2 = round(sqrt(sum((yhat.bag-Data.T[,3])^2)/50) ,3)
rmse.3 = round(sqrt(sum((yhat.for-Data.T[,3])^2)/50) ,3)
rmse.4 = round(sqrt(sum((yhat.boost-Data.T[,3])^2)/50) ,3)

cat(paste("==========RMSE \n\n",
          "Regression Tree\t : ",rmse.1,"\n",
          "Bagging  \t : ",rmse.2,"\n",
          "Random Forest\t : ",rmse.3,"\n",
          "Boosting\t : ",rmse.4,"\n",sep=""))  #### n.trees = 200000   --> 28.26

