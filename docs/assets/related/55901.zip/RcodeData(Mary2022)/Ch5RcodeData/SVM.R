#�@�p�b�P�[�W�̓ǂݍ���
install.packages("e1071")
library(e1071)
## Data  
## Wholesale customers Data Set  from UCI  http://archive.ics.uci.edu/ml/datasets/Wholesale+customers#

#�A�f�[�^�̓ǂݍ���
dat = read.csv("cus.csv",header=TRUE)

## Training , Test Data

dat$Channel = as.factor(dat$Channel)

set.seed(1)
train= sample(1:nrow(dat),400)
test = sample((1:nrow(dat))[-train],40)


#�B�T�|�[�g�x�N�g���}�V�[���̐ݒ�ƍœK���v�Z
## Tuneout
tune.out=tune(svm,Channel~.,data=dat[train,],kernel="radial",decision.values=T,
              ranges=list(cost=c(0.0001,0.001,0.1,1,10,50,100),gamma=c(0.001,0.01,0.1,1,10,50)),scale=TRUE)
svm.fit = tune.out$best.model
summary(svm.fit)

#�C�����s��
## Confusion matrix
svm.pred.train = predict(svm.fit,newdata=dat[train,],decision.values=TRUE)
svm.pred.test = predict(svm.fit,newdata=dat[test,],decision.values=TRUE)
(table.svm.train = table(svm.pred.train,dat[train,"Channel"]))
(table.svm.test = table(svm.pred.test,dat[test,"Channel"]))

#�D���ʂ̉����F�听�����͂ɂɂ�鎟���k��
### PCA

dat.sc=dat[train,]
dat.sc[,2:(ncol(dat))] = scale(dat[train,2:(ncol(dat))])

pr = princomp(dat.sc[,2:(ncol(dat.sc))])
summary(pr)   ## over 60% with 2 comp
pr$loadings

## Plot
a = svm.fit$decision.values
plot(a)
for(i in 1:length(a)){
  if(a[i] > 0 ){a[i] = 4}
  else{a[i] = 2}
}
b = a
for(i in 1:length(b)){
  if(b[i] == 2){b[i]="blue"}
  else{b[i]="red"}
}
plot(pr$scores[,1:2],pch=a,col=b)

f = as.data.frame(cbind(dat.sc,pr$scores[,1:2]))

plot(svm.fit,data=f,Comp.2~Comp.1)


#### package kernlab 
### plot PCA result with ksvm
library(kernlab)

dat3 = data.frame(pr$scores[,1:2],Channel = dat$Channel[train])
svm.fit3 = ksvm(Channel ~.,data=dat3)
plot(svm.fit3,data=dat3)


#�EROC�Ȑ�
library(ROCR)
rocplot=function(pred, truth, ...){
  predob = prediction(pred, truth)
  perf = performance(predob, "tpr", "fpr")
  plot(perf,...)
  return(perf)}


par(mfrow=c(1,1))

roc.tr = rocplot(-attributes(svm.pred.train)$decision.values,dat[train,"Channel"],col="red",main="ROC Curves",lty=2)
roc.t = rocplot(-attributes(svm.pred.test)$decision.values,dat[test,"Channel"],col="blue",add=T,lty=1)
legend("bottomright",legend=c("Test","Training"),col=c("blue","red"),lty=c(1,2))
