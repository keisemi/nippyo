## Packages
# ROC�Ȑ��p�b�P�[�W�̃C���X�g�[��
install.packages("ROCR")

###### �@ Read Data

####Imbalanced Data
imb.dat.tr = read.table("Hi.tr.csv",sep=",",header=TRUE)
imb.dat.t = read.table("Hi.t.csv",sep=",",header=TRUE)
##### balanced Data
bal.dat.tr = data.frame(rbind(subset(imb.dat.tr,imb.dat.tr$y=="yes"),subset(imb.dat.tr,imb.dat.tr$y=="no")[1:200,]))
bal.dat.t = data.frame(rbind(subset(imb.dat.t,imb.dat.t$y=="yes"),subset(imb.dat.t,imb.dat.t$y=="no")[1:20,]))

###  �A�l�X�Ȋ֐��̒�`
###  LDA
library(MASS)
LDA = function(dat.tr,dat.t){
  lda.fit = lda(y~.,data=dat.tr)
  lda.pred.train = predict(lda.fit,data=dat.tr)
  lda.pred.test = predict(lda.fit,newdata=dat.t)
  (lda.table.train = table(lda.pred.train$class,dat.tr$y))
  (lda.table.test = table(lda.pred.test$class,dat.t$y))
  cat(paste("lda.misclassification rate(Training):\t",(lda.table.train[1,2]+lda.table.train[2,1])/sum(lda.table.train),"\n"))
  cat(paste("lda.misclassification rate(Test):\t",(lda.table.test[1,2]+lda.table.test[2,1])/sum(lda.table.test),"\n"))
  return(list(call=lda.fit,table.tr=lda.table.train,table.t=lda.table.test,pred.tr=lda.pred.train,pred.t=lda.pred.test))
}

###  Logistic Regression
logistic = function(dat.tr,dat.t){
  glm.fit =glm(y~.,data=dat.tr,family = binomial)
  summary(glm.fit)
  glm.pred.train = predict(glm.fit,data=dat.tr,type="response")
  glm.pred.test = predict(glm.fit,newdata=dat.t,type="response")
  pred.tr = glm.pred.train
  pred.t = glm.pred.test
  for(i in 1:length(pred.tr)){if(pred.tr[i]>0.5){pred.tr[i]=1}else{pred.tr[i]=0}}
  for(i in 1:length(pred.t)){if(pred.t[i]>0.5){pred.t[i]=1}else{pred.t[i]=0}}
  (glm.table.train = table(pred.tr,dat.tr$y))
  (glm.table.test = table(pred.t,dat.t$y))
  cat(paste("glm.misclassification rate(Training):\t",(glm.table.train[1,2]+glm.table.train[2,1])/sum(glm.table.train),"\n"))
  cat(paste("glm.misclassification rate(Test):\t",(glm.table.test[1,2]+glm.table.test[2,1])/sum(glm.table.test),"\n"))
  return(list(coef = summary(glm.fit),table.tr=glm.table.train,table.t=glm.table.test,pred.tr=glm.pred.train,pred.t=glm.pred.test))
}

#### ROC�Ȑ�
library(ROCR)
roc = function(dat.tr,dat.t,glm,lda){
  rocplot=function(pred, truth, ...){
    predob = prediction(pred, truth)
    perf = performance(predob, "tpr", "fpr")
    plot(perf,...)
    return(perf)}
par(mfrow=c(1,2))
  roc.glm.tr = rocplot(glm$pred.tr,dat.tr$y,col="red",main="Training Data",lty=2)
  roc.lda.tr = rocplot(lda$pred.tr$posterior[,2],dat.tr$y,add=T,col="blue",lty=1)
  legend("bottomright",legend=c("LDA","Logistic"),col=c("blue","red"),lty=c(1,2))
  
  roc.glm.t = rocplot(lda$pred.t$posterior[,2],dat.t$y,main="Test Data",lty=2)
  roc.lda.t = rocplot(glm$pred.t,dat.t$y,add=T,col="red",lty=1)
  legend("bottomright",legend=c("LDA","Logistic"),col=c("black","red"),lty=c(1,2))
  return(list(roc.glm.tr=roc.glm.tr,roc.glm.t=roc.glm.t,roc.lda.tr=roc.lda.tr,roc.lda.t=roc.lda.t))
}


#### �B Model Fit �FLDA, Logistic Regression (2 datasets)
lda.imb = LDA(imb.dat.tr,imb.dat.t)
lda.bal = LDA(bal.dat.tr,bal.dat.t)
lda.imb$call
lda.bal$call

# 20201.07.01 update [line 71-75] �p�b�P�[�W�̕ω��ɂ��A���O�Ƀ_�~�[�ϐ��ɕϊ�����K�v������
bal.dat.tr$y = ifelse(bal.dat.tr$y == 'yes', 1, 0)
bal.dat.t$y = ifelse(bal.dat.t$y == 'yes', 1, 0)
imb.dat.tr$y = ifelse(imb.dat.tr$y == 'yes', 1, 0)
imb.dat.t$y = ifelse(imb.dat.t$y == 'yes', 1, 0)

glm.bal = logistic(bal.dat.tr,bal.dat.t)
glm.imb = logistic(imb.dat.tr,imb.dat.t)
glm.imb$coef
glm.bal$coef

#### ROC�Ȑ�
roc.imb = roc(imb.dat.tr,imb.dat.t,glm.imb,lda.imb)
roc.bal = roc(bal.dat.tr,bal.dat.t,glm.bal,lda.bal)

#### �C �o�� Confusion Matrix, False.Positive, True Negative, Cut Point
lda.imb$table.tr ; lda.imb$table.t
lda.bal$table.tr ; lda.bal$table.t
glm.imb$table.tr ; glm.imb$table.t
glm.bal$table.tr ; glm.bal$table.t
roc.imb$roc.glm.tr
