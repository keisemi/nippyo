## Data from: http://mo161.soci.ous.ac.jp/@d/DoDStat/PLIlive/PLIlive_dataJ.xml   
#install.packages("glmnet")
#�@�p�b�P�[�W�̓ǂݍ���
library(glmnet)

### �A�f�[�^�̓ǂݍ��� �ƕϐ��̎w��
dat = read.csv("PLIliveJ.csv")
head(dat)
x <- as.matrix(dat[,-c(1,4)])   ## �ƒ��ȊO������ϐ�
name <- dat[,1]
y <- (dat[,4])                  ## �ƒ���ړI�ϐ�
dat.m <- list(x=x,name=name,y=y)
set.seed(1)
s <- sample(1:30,18)     ### Training Samples
t <- (1:30)[-s]    ### Test Samples

###�B���f���̂��Ă͂�
## alpha = 1 <- lasso   alpha = 0 <- Ridge   else Elastic Net

Ridge <- glmnet(dat.m$x[s,],dat.m$y[s],alpha = 0,family="gaussian")   ### Ridge
Lasso <- glmnet(dat.m$x[s,],dat.m$y[s],alpha = 1,family="gaussian")   ### Lasso
par(mfrow=c(1,2))
plot(Ridge)
plot(Lasso)

Lasso

###�C�N���X�o���f�[�V�����̎��s
las.cv <- cv.glmnet(dat.m$x[s,],dat.m$y[s],alpha = 1,family="gaussian",nfolds=3)  ### cross validation    nfolds=num.cv
rid.cv <- cv.glmnet(dat.m$x[s,],dat.m$y[s],alpha = 0,family="gaussian",nfolds=5)  ### cross validation    nfolds=num.cv

min(rid.cv$cvm)   ### min mse
rid.cv$lambda.min ### min lambda
las.cv$lambda
min(las.cv$cvm)   ### min mse
las.cv$lambda.min ### min lambda


plot(Ridge, xvar="lambda", label=TRUE,main="Ridge")
abline(v=log(rid.cv$lambda.min), lty=2)   ## with min lambd estimate penaly


plot(Lasso, xvar="lambda", label=TRUE,main="Lasso")
abline(v=log(las.cv$lambda.min), lty=2)   ## with min lambd estimate penaly

coef = cbind( coef(rid.cv,s="lambda.min"),
coef(las.cv,s="lambda.min"))
colnames(coef)=c("ridge","LASSO")
coef

##�D�\��
#In sample
pred <- predict(las.cv,s="lambda.min",newx=dat.m$x[s,])
pred2 <- predict(rid.cv,s="lambda.min",newx=dat.m$x[s,])

par(mfrow=c(1,2))
plot(dat.m$y[s],type="l",main="Training Data",xlab="region",ylab="rent")
lines(pred,col="red",lty=2)
lines(pred2,col="blue",lty=2)
legend("topleft",legend = c("Lasso","Ridge"),lty=2,col=c("red","blue"))

#Forecast
pred3 <- predict(las.cv,s="lambda.min",newx=dat.m$x[t,])
pred4 <- predict(rid.cv,s="lambda.min",newx=dat.m$x[t,])
plot(dat.m$y[t],type="l",main="Test Data",ylim=c(1600,3800),xlab="region",ylab="rent")
lines(pred3,col="red",lty=2)
lines(pred4,col="blue",lty=2)
legend("topleft",legend = c("Lasso","Ridge"),lty=2,col=c("red","blue"))

