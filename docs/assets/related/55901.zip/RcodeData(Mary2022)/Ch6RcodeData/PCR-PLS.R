## install.packages("pls")
## install.packages("chemometrics")
##�@���C�u�����̓ǂݍ���
library(pls)
library(chemometrics)

##�A�f�[�^�̓ǂݍ��݂ƕW����
dat <- read.csv("com.csv")
dat.sc = as.data.frame(scale(dat))
#head(dat)

##�B���f���̂��Ă͂�2. PLS
#�@�听����A
pcr.fit <- pcr(price ~ .,data=dat.sc,ncomp=4)
#pcr.fit <- pcr(price ~ .,data=dat.sc,validation="CV")
W <-pcr.fit$coefficients[,,]
P <-pcr.fit$loadings
(C <-as.vector(pcr.fit$Yloadings))
par(mfrow=c(1,2))
plot(pcr.fit,"validation",main="price(PCR)")
plot(pcr.fit,"coefficients",main="price(PCR)")
## XY coef
(pca.b = W %*% C )

#�@PLS��A
pls.n <- pls1_nipals(dat[,-1],dat$price,4,scale=TRUE)
## XY coef
P = pls.n$P
(C = pls.n$C)
W = pls.n$W
(ni.b= W %*% solve(t(P)%*% W) %*% C )

#�C���q���̐���

plot(pls.n$C,main="price(nipals)",xlab="number of components",ylab="RMSEP",type="l",xaxt="n")
axis(side=1,at=1:4,las=1)
plot(ni.b,type="l",main="price(nipals)",xlab="variable",ylab="coefficient")
abline(h=0,col="grey")

##�D����
pred.pr <- as.matrix(dat.sc[,-1]) %*% pca.b
pred.n <- as.matrix(dat.sc[,-1]) %*% ni.b

par(mfrow=c(2,1))

plot(scale(dat$price),main="PCR Estimate",xlab="Data",ylab="scaled price")
#lines(rowMeans(pred.pr[,,]),lty=1,col="red")
lines(pred.pr,lty=1,col="red")
legend("topright",legend=c("data","estimate"),lty=c(0,1),pch = c(1,NA),col=c("black","red"))

plot(scale(dat$price),main="PLS Estimate",xlab="Data",ylab="scaled price")
lines(pred.n,lty=1,col="red")
legend("topright",legend=c("data","estimate"),lty=c(0,1),pch = c(1,NA),col=c("black","red"))



## Prices of Personal Computers
# A dataframe containing :
#   price - price in US dollars of 486 PCs
# speed - clock speed in MHz
# hd - size of hard drive in MB
# ram - size of Ram in in MB
# screen -  size of screen in inches
# cd -  is a CD-ROM present ?
# multi - is a multimedia kit (speakers, sound card) included ?
# premium - is the manufacturer was a "premium" firm (IBM, COMPAQ) ?
# ads - number of 486 price listings for each month
# trend - time trend indicating month starting from January of 1993 to November of 1995.


