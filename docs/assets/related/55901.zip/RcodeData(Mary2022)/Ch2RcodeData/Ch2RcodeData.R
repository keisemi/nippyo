#--------------------------------------------------
## 001 
# R�ɂ����镪�z�`�� :�x�[�^���z
p = seq(0,1,length=500)
a = 5
b = 5
s = 15
ns = 25
prior = dbeta(p, a, b)
like = dbeta(p, s, ns)
post = dbeta(p, a + s, b + ns)
Names <- c("���O���z","�ޓx�֐�", "���㕪�z")
plot(p,prior,ylim=range(post),type="l",main="�x�[�^�[�񍀕��z",xlab="x",ylab="Density",
     lty=1,lwd=1)
lines(p,like,type="l",lty=2,lwd=1)
lines(p,post,type="l",lty=3,lwd=1)
legend(0,5,Names,col=1,lty=1:3)



#--------------------------------------------------
### 003 page 59
# R�ɂ�鐳�K��W�c�̃M�b�u�X�T���v�����O
# Gibbs sampler for non conjugat Normal-Gamma
y <- c(1.53, 19.02, 5.34, -2.16, 0.83, 6.74, 5.53,
       0.65, -0.49, -0.08, 5.31, 3.18, 7.19, 4.23, 6.45)
my <- mean(y); n <- length(y)
iterations <- 3500
m0 <- 0; s0 <- 100; a0 <- 0.01; b0 <- 0.01
theta <- matrix(nrow = iterations, ncol = 2)
cur.mu <- 0; cur.tau <- 1
cur.s <- sqrt(1 / cur.tau)
for (t in 1:iterations){
  w <- s0 ^ 2 / (cur.s ^ 2 / n + s0 ^ 2)
  m <- w * my + (1 - w) * m0
  s <- sqrt(w + cur.s ^ 2 / n)
  cur.mu <- rnorm(1, m, s)
  a <- a0 + 0.5 * n
  b <- b0 + 0.5 * sum((y - cur.mu) ^ 2)
  cur.tau <- rgamma(1, a, b)
  cur.s <- sqrt(1 / cur.tau)
  theta[t,] <- c(cur.mu, cur.s) }
op <- par(mfrow = c(2, 1))
p = 1:iterations
plot(p,theta[, 1],type="l",main="mu",xlab=" iteration",
     ylab="mu",lty=1,lwd=1)
plot(p,theta[, 2],type="l",main="sigma",xlab=" iteration",
     ylab="sigma",lty=1,lwd=1)
par(op)


#------------------------------------------------
