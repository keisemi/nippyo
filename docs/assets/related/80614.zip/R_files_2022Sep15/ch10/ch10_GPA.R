# GPAを決める要因の分析 10章　
#########################	
  # 章末問題10.2(1)
#########################
# estimatrパッケージを使います。パッケージをインストールしていない場合には、
# install.packages("estimatr")　
# を実行しパッケージをインストールしてください。
library(estimatr)

# データの読み込み。Rの作業ディレクトリにGPA2.csvを保存すること。
df_gpa <- read.csv("GPA2.csv")
# 通学時間を示すカテゴリー変数の順序の入れ替え
df_gpa$commute <- factor(df_gpa$commute, levels=c("30分未満","30分以上1時間未満", "1時間以上1時間30分未満", "1時間30分以上2時間未満", "2時間以上3時間未満", "3時間以上" ))

# OLS推定（均一分散）
ols_single <- lm(GPA ~ study_time, data= df_gpa) 
ols_gpa2 <- lm(GPA ~ study_time+ circle_time + hobby_time+ work_time+ game_time, data= df_gpa) 
ols_gpa3 <- lm(GPA ~ study_time+ circle_time + hobby_time+ work_time+ game_time +  female +  family, data= df_gpa) 
ols_gpa4 <- lm(GPA ~ study_time+ circle_time + hobby_time+ work_time+ game_time + commute+ time_commute, data= df_gpa) 
ols2 <- lm(GPA ~ study_time+ circle_time + hobby_time+ work_time+ game_time +  female +  family+ commute+ time_commute, data= df_gpa)

summary(ols_single) #表の(1)
summary(ols_gpa2) #表の(2)
summary(ols_gpa3) #表の(3)
summary(ols_gpa4) #表の(4)
summary(ols2) #表の(5)


#########################		
  # 章末問題10.2(2)
#########################
# OLS推定（HC2標準誤差）
ols2_robust <- lm_robust(GPA ~ study_time+ circle_time + hobby_time+ work_time+ game_time +  female +  family+ commute+ time_commute, data= df_gpa)
summary(ols2_robust)
