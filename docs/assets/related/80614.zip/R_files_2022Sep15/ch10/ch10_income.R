# 留学生の収入に関する分析
#########################
  # 章末問題10.1 (1)
##########################
# estimatrパッケージを使います。パッケージをインストールしていない場合には、
# install.packages("estimatr")　
# を実行しパッケージをインストールしてください。
library(estimatr)

# データの読み込み。Rの作業ディレクトリにincome2.csvを保存すること。
df_ols <- read.csv("income2.csv")
n <- length(df_ols[,1])

#単回帰分析（均一分散）、教科書の(10.2)式に該当
results <- lm(income~exchange, data= df_ols)
summary(results)

#重回帰分析（均一分散）、教科書の(10.4)式に該当
results_multi <- lm(income~exchange + family + region + female, data= df_ols)
summary(results_multi)


#########################
  # 章末問題10.1 (2)
##########################
#単回帰分析（HC2-standard error）
results_robust <- lm_robust(income~exchange, data= df_ols)
summary(results_robust)

#重回帰分析（HC2-standard error）
results_multi_robust <- lm_robust(income~exchange + family + region + female, data= df_ols)
summary(results_multi_robust)

