########################
  # Chapter 13, 14  操作変数法
########################
# psych パッケージと AER パッケージを使います。パッケージをインストールしていない場合には、
# install.packages("psych")　
# install.packages("AER")　
# を実行しパッケージをインストールしてください。
library(psych)	#記述統計を示すために使うパッケージ
library(AER)	# ivreg関数を使うためのパッケージ

# データの読み込み
df <- read.csv("EngelCurve.csv", row.names=1)
# 記述統計
psych::describe(df)


#########################
		#章末問題　14.4  
##########################
# エンゲル曲線の操作変数法による推定
# (1) 操作変数推定量（例題13.2の推定結果の再現）
resultsIV <- ivreg(app_expRate~ lnExp | lnInc, data= df)
summary(resultsIV)	#ここで示される標準誤差は均一分散を仮定した下での標準誤差であることに注意。

# (2) 2SLS推定量（例題14.1の推定結果の再現）
results2SLS <- ivreg(app_expRate~ lnExp+ GPA + game_time+ Kanto + female + family | lnInc + GPA + game_time+ Kanto + female + family, data= df)
summary(results2SLS, diagnostic=TRUE, vcov=sandwich, df = Inf)		#標準誤差は不均一分散に対して頑健な標準誤差を指定。
# (3) 上記のコマンドの実行結果にある「Weak instruments」は１段階目のF統計量を示している
# (5) 結果にある「wald test」は、定数項以外の係数が0という帰無仮説の検定になっている。



#########################
		# 補足：2SLSの残差を手動で計算
##########################
# 1st stage regression
first <-  lm(lnExp  ~ lnInc + GPA + game_time+ Kanto + female + family , data= df)
fitted <- first$fitted	# first stageの予測値
# 2nd stage regression
second <- lm(app_expRate~ fitted + GPA + game_time+ Kanto + female + family , data= df)

# テキスト14.2節で表示した不均一分散に頑健な標準誤差を直接計算する。
Covariates <- cbind(rep(1,n), df$lnExp, df$GPA, df$game_time, df$Kanto, df$female, df$living_a, df$living_f)
# 2slsの結果を用いて、元のモデルの予測値を計算
twoslsfitted <- rowSums(t(t(Covariates) *second$coefficients))
# 2slsの結果を用いて、元のモデルの残差を計算
twosls_residuals <- df$app_expRate - twoslsfitted
n <- length(df[,1])	#サンプルサイズ
# 標準誤差の計算
hatX <- cbind(rep(1,n), fitted, df$GPA, df$game_time, df$Kanto, df$female, df$living_f, df$living_a)
Sigma_2sls <- n*solve(t(hatX)%*%hatX)%*%(t(hatX)%*%diag(twosls_residuals^2)%*%hatX)%*%(solve(t(hatX)%*%hatX)) 
(TwoSLSsderror <- sqrt(diag(Sigma_2sls)/n))


#########################
		# 補足：wald統計量を手動で計算
##########################
# 上で示したように、例題14.3で考えているwald検定はsummary関数を用いて得ることができるが、ここでは自分でコードを書いて計算してみる。
#H_0: 定数項以外のすべての係数が0
n <- length(df[,1])	# 標本サイズ
R <- diag(1,8)			
R <- R[-1,]
r <- rep(0,7)
Sigma <- n*vcovHC(results2SLS, method=c("arellano"), type="HC0")  # Sigma_2slsと同じ
beta <- results2SLS $coefficients
# Wald statistic
(Wald <- n*t(R%*%beta-r)%*%  solve(R%*% Sigma%*%t(R))%*%(R%*%beta-r))
# F statistic
(Fstat <- Wald/7)

