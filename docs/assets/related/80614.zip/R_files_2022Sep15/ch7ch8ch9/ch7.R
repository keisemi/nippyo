#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    # 例題 7.1, 7.2, 7.3
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# データの読み込み
df <- read.csv(file="income1.csv")
summary(df)
df <- data.frame(df)
attach(df)

# 例題 7.1
(beta_1 <- cov(international, income)/var(international))
(beta_0 <- mean(income)-beta_1*mean(international))

# 例題 7.2 
tilde_international <- lm(international ~ male + alone + other)$residuals
tilde_income <- lm(income ~ male + alone + other)$residuals
(alpha_1 <- mean(tilde_international*tilde_income)/ mean(tilde_international^2))

# 例題 7.3
summary(lm(income ~ international))
summary(lm(income ~ international + male + alone + other))


#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# 章末問題7.4
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# データの読み込み
df <- read.csv(file="GPA1.csv")
summary(df)
df <- data.frame(df)
attach(df)

# (1)
mean(GPA)
mean(female)
var(GPA)
var(female)
cov(female,GPA )

(alpha1 <- cov(female,GPA )/ var(female))
(alpha0 <- mean(GPA)-mean(female)* alpha1)

# (3)
tilde_female <- lm(female ~ circle + partTime + study_time)$residuals
tilde_GPA <- lm(GPA ~ circle + partTime + study_time)$residuals

mean(tilde_female*tilde_GPA)
mean(tilde_female^2)

(beta1 <- cov(tilde_female,tilde_GPA )/ var(tilde_female))


#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# 章末問題7.5
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# データの読み込み
df <- read.csv(file="GPA1.csv")
summary(df)
df <- data.frame(df)
attach(df)

# 最小2乗法による単回帰モデルの推定
ols <- lm(GPA ~ female)
summary(ols)

# 重回帰モデルの推定
ols <- lm(GPA ~ female + circle + partTime + study_time)
summary(ols)











