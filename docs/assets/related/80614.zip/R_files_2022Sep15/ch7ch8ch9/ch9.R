#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    # 例題 9.1, 9.2, 9.5, 9.6
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# estimatrパッケージが必要です。パッケージのインストールをしたことがない場合には、
# install.packages("estimatr")　
# をRのコンソールで実行しパッケージをインストールしてください。

# パッケージの読み込み
library(estimatr)

# データの読み込み
df <- read.csv(file="income1.csv")
summary(df)
df <- data.frame(df)
attach(df)


#　例題 9.1
# 最小2乗法による推定
summary(lm_robust(income ~ international + male + alone + other, se_type="HC2"))
# OLS estimates 
(estimates <- round(coef(summary(lm_robust(income ~ international + male + alone + other, se_type="HC2")))[,1],2))
# OLS standard Error 
(stderror <- round(coef(summary(lm_robust(income ~ international + male + alone + other, se_type="HC2")))[,2],2))

# 自作の関数で信頼区間の導出します。次の関数を定義したあと、f(z)を実行すると、すべての係数に対する信頼区間が計算されます。
# zは、教科書の表9.1にあるz_{α/2}です。信頼水準90%ならzは1.64、95%ならzは1.96、99%ならzは2.58です。
f <- function(z){
  output <- rbind(estimates - z*stderror, estimates + z*stderror)
  row.names(output) <- c("lower", "upper")
  output
}
# (1) 95% 信頼区間
round(f(1.96),2)
# (2) 90% 信頼区間
round(f(1.64),2)
# (3) 99% 信頼区間
round(f(2.58),2)

# confint関数を使って信頼区間を導出することもできます。
# (1) 95% 
confint(lm_robust(income ~ international + male + alone + other, se_type="HC2"),level=0.95)
# (2) 90%
confint(lm_robust(income ~ international + male + alone + other, se_type="HC2"),level=0.90)
# (3) 99% 
confint(lm_robust(income ~ international + male + alone + other, se_type="HC2"),level=0.99)


#　例題 9.2
# 最小2乗法による推定
summary(lm_robust(income ~ international + male + alone + other, se_type="HC2"))
# t検定統計量の値は、t valueの列に表示されている。

# 解答例では、四捨五入した値を用いて次のように計算した。
round(tvalue <- estimates/stderror,2)


#　例題 9.5
# wald統計量の値の計算
# aodパッケージが必要です。パッケージのインストールをしたことがない場合には、
# install.packages("aod")　
# を実行しパッケージをインストールしてください。
library(aod)
# 最小2乗法による推定結果をresultsという名前で保存し、wald.test関数を用いてwald統計量の値の計算する。
results <- lm_robust(income ~ international + male + alone + other, se_type="HC2")
wald.test(b=coef(results), Sigma=vcov(results),Terms=2:5)

# 定義の通りに自力で計算することもできます。
R <- diag(5)
R <- R[2:5,]
r <- rep(0,4)
t(R%*%estimates-r)%*%solve(R%*%vcov(results)%*%t(R))%*%(R%*%estimates-r)


#　例題 9.6
137.7/4 # = wald/r
# summary(lm_robust())関数で排出されるF統計量は、定数項を除く説明変数の係数が全て0であるという帰無仮説に対するもの。
#　つまり、H_0: beta2=...beta5=0 を考えている。
Fstat <- (summary(lm_robust(income ~ international + male + alone + other, se_type="HC2"))$fstatistic)[1]
(Fstat) #:F
(Fstat*4) #:wald


#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# 章末問題9.3
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# 上記の例題9.5と例題9.6を参照せよ。


#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# 章末問題9.4
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# パッケージの読み込み
library(estimatr)

# データの読み込み
df <- read.csv(file="GPA1.csv")
summary(df)
df <- data.frame(df)
attach(df)

# 最小2乗法による推定
ols <- lm_robust(GPA ~ female + circle + partTime + study_time, se_type="HC2")
summary(ols)
# 四捨五入した推定値と標準誤差
(round(coef(summary(lm_robust(GPA ~ female + circle + partTime + study_time, se_type="HC2")))[,1],3))
(round(coef(summary(lm_robust(GPA ~ female + circle + partTime + study_time, se_type="HC2")))[,2],3))

# (1) 99% confidence interval
# confint関数を使って信頼区間を導出する。
confint(ols,level=0.99)
round(confint(ols,level=0.99),3)

# (2) t value がt検定統計量の値
summary(ols)
# 四捨五入したt検定統計量の値
round(summary(ols)$coefficients[,"t value"],3)

# (3) F-statistic がF統計量の値
summary(ols)
# 四捨五入したF統計量の値
round(summary(ols)$fstatistic,3)[1]

# (4) wald統計量を計算する。
estimates <- coef(summary(lm_robust(GPA ~ female + circle + partTime + study_time, se_type="HC2")))[,1]
R <- diag(5)
R <- rbind(R[2,], R[5,])
r <- rep(0,2)
(wald <- t(R%*%estimates-r)%*%solve(R%*%vcov(ols)%*%t(R))%*%(R%*%estimates-r))
# 四捨五入したワルド統計量の値
round(wald,3)

