#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# 章末問題8.4
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# データの読み込み
df <- read.csv(file="GPA1.csv")
n <- length(df[,1])
# データセットに含まれている変数の記述統計量の表示
summary(df)


# (1)重回帰モデルの推定（分散均一）
ols <- lm(GPA ~ female + circle + partTime + study_time, data=df)
summary(ols) # 表示された結果の、Std. Errorの列が分散均一の仮定の下での、OLS推定量の標準誤差です。
# OLS推定量の標準誤差を四捨五入したもの
round(summary(ols)$coefficients[,2],5)


# 次のように、lm関数を使わずに直接計算することもできます。
hat_epsilon <- ols$residuals
Covariates <- as.matrix(cbind(const=rep(1,n),df[,-1]))
Sigma_hat_homoskedastic <- (sum(hat_epsilon^2)/(n-5))*solve(t(Covariates)%*%Covariates/n)
VarMatrix_homoskedastic <- Sigma_hat_homoskedastic/n
(standardErrors_homoskedastic <- diag(VarMatrix_homoskedastic)^{1/2})


# (2)~(4)重回帰モデルの推定（分散不均一）
# estimatrパッケージが必要です。パッケージのインストールをしたことがない場合には、
# install.packages("estimatr")　
# をRのコンソールで実行しパッケージをインストールしてください。
library(estimatr)
ols_robust_HC0 <- lm_robust(GPA ~ female + circle + partTime + study_time, data=df, se_type="HC0")
ols_robust_HC1 <- lm_robust(GPA ~ female + circle + partTime + study_time, data=df, se_type="HC1")
ols_robust_HC2 <- lm_robust(GPA ~ female + circle + partTime + study_time, data=df, se_type="HC2")
summary(ols_robust_HC0) # 表示された結果の、Std. Errorの列がOLS推定量の標準誤差のHC0推定量です。
summary(ols_robust_HC1) # 表示された結果の、Std. Errorの列がOLS推定量の標準誤差のHC1推定量です。
summary(ols_robust_HC2) # 表示された結果の、Std. Errorの列がOLS推定量の標準誤差のHC2推定量です。
# OLS推定量の標準誤差を四捨五入したもの
round(summary(ols_robust_HC0)$coefficients[,2],5)
round(summary(ols_robust_HC1)$coefficients[,2],5)
round(summary(ols_robust_HC2)$coefficients[,2],5)

# 次のように、lm_robust関数を使わずに直接計算することもできます。
# HC0
Sigma_hat_hc0 <- solve(t(Covariates)%*%Covariates/n)%*%(t(hat_epsilon*Covariates)%*%(hat_epsilon*Covariates)/n)%*%solve(t(Covariates)%*%Covariates/n)
(standardErrors_hc0 <- diag(Sigma_hat_hc0/n)^{1/2})

# HC1
Sigma_hat_hc1 <- solve(t(Covariates)%*%Covariates/n)%*%(t(hat_epsilon*Covariates)%*%(hat_epsilon*Covariates)/(n-5))%*%solve(t(Covariates)%*%Covariates/n)
(standardErrors_hc1 <- diag(Sigma_hat_hc1/n)^{1/2})

# HC2
k <- diag(Covariates%*% solve(t(Covariates)%*%Covariates)%*%t(Covariates))
tilde_epsilon <- ols$residuals/(1-k)^{1/2}
Sigma_hat_hc2 <- solve(t(Covariates)%*%Covariates/n)%*%(t(tilde_epsilon*Covariates)%*%(tilde_epsilon*Covariates)/n)%*%solve(t(Covariates)%*%Covariates/n)
(standardErrors_hc2 <- diag(Sigma_hat_hc2/n)^{1/2})
