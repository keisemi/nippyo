########################
# 12章　章末問題12.3
########################
# plmパッケージとlmtestパッケージを使います。パッケージをインストールしていない場合には、
# install.packages("plm")　
# install.packages("lmtest")　
# を実行しパッケージをインストールしてください。
library(lmtest)
library(plm)

df <- read.csv("testScore.csv")
n <- length(df[,1])


####################
	# 例題12.1 
#################
# 固定効果推定量
fixM_Language_a <- plm(Language_a ~ lunch_day+ num_school + num_child_La + FPI, data=df, effect=c("individual"), index=("Prefecture"), model="within")
coeftest(fixM_Language_a, vcov=vcovHC, type="HC2")
# 推定値
estimates <- round(coeftest(fixM_Language_a, vcov=vcovHC, type="HC2")[,1],3)
# HC2標準誤差
stderror <- round(coeftest(fixM_Language_a, vcov=vcovHC, type="HC2")[,2],3)

# 自作の関数で信頼区間の導出します。次の関数を定義したあと、f(z)を実行すると、すべての係数に対する信頼区間が計算されます。
# zは、教科書の表9.1にあるz_{α/2}です。信頼水準90%ならzは1.64、95%ならzは1.96、99%ならzは2.58です。
f <- function(z){
  output <- rbind(estimates - z*stderror, estimates + z*stderror)
  row.names(output) <- c("lower", "upper")
  output
}
# (1) 90% 信頼区間
f(1.64)
# (2) 95% 信頼区間
f(1.96)
# (3) 99% 信頼区間
f(2.58)


####################
	# 例題12.3
#################
# (12.12)式を固定効果推定した結果は、例題12.1で計算した「fixM_Language_a」です。
# "lmtest"パッケージのwaldtest関数を使ったワルド統計量とF統計量の導出方法を紹介します。
# waldtest関数を使うには、まず、帰無仮説の下でのモデルの固定効果推定量を計算します。
fixM_Language_a_Restricted <- plm(Language_a ~ lunch_day, data=df, effect=c("individual"), index=("Prefecture"), model="within")

# waldtest関数では、元のモデルの推定結果（fixM_Language_a）と、帰無仮説の下での推定結果（fixM_Language_a_Restricted）を使い
# ワルド統計量やF統計量を計算します。

# (3) wald statistic
waldtest(fixM_Language_a_Restricted, fixM_Language_a, vcov=vcovHC(fixM_Language_a, type="HC2"), test="Chisq")
# (5) F statistic
waldtest(fixM_Language_a_Restricted, fixM_Language_a, vcov=vcovHC(fixM_Language_a, type="HC2"), test="F")


####################
	# 例題12.5
#################
# pdata.frame関数を使って、個人（都道府県）と時間（観測年）を表す変数を指定します。
df_panel <- pdata.frame(df, index=c("Prefecture", "year"))

# 時間効果推定量
Time_Language_a <- plm(Language_a ~ lunch_day+ num_school + num_child_La + FPI, data= df_panel, effect ="time", model="within")
coeftest(Time_Language_a, vcov=vcovHC, type="HC2")

# 推定値
(estimates <- round(coeftest(Time_Language_a, vcov=vcovHC, type="HC2")[,1],3))
# HC2標準誤差
(stderror <- round(coeftest(Time_Language_a, vcov=vcovHC, type="HC2")[,2],3))

# (1) 95%信頼区間
f(1.96)
# (2)  上記の結果から計算できる。

# waldtest関数を使うために、帰無仮説の下でのモデルの固定効果推定量を計算します。
Time_Language_a_restricted<- plm(Language_a ~ lunch_day+ FPI, data= df_panel, effect ="time", model="within")
# (5) wald statistic
waldtest(Time_Language_a_restricted, Time_Language_a, vcov=vcovHC(Time_Language_a, type="HC2"), test="Chisq")
# (6) F statistic
waldtest(Time_Language_a_restricted, Time_Language_a, vcov=vcovHC(Time_Language_a, type="HC2"), test="F")


####################
	# 例題12.7
#################
# 固定効果と時間効果を除去したモデルの推定量 
# (1)と(2)
fixtimeM_Language_a <- plm(Language_a ~ lunch_day+ num_school + num_child_La + FPI, data= df_panel, effect ="twoways", model="within")
coeftest(fixtimeM_Language_a, vcov=vcovHC, type="HC2", method=c("arellano"))

# 推定値
(estimates <- round(coeftest(fixtimeM_Language_a, vcov=vcovHC, type="HC2")[,1],3))
# HC2標準誤差
(stderror <- round(coeftest(fixtimeM_Language_a, vcov=vcovHC, type="HC2")[,2],3))

# (1) 90%信頼区間
f(1.64)
# (2)  上記の結果から計算できる。

# 今回は定義の通りに自力で計算します。
Sigma <- n*vcovHC(fixtimeM_Language_a, method=c("arellano"), type="HC2")
R <- diag(1,4)
r <- rep(0,4)
beta <- fixtimeM_Language_a$coefficients
# (5) Wald statistic
(Wald <- n*t(R%*%beta-r)%*%  solve(R%*% Sigma%*%t(R))%*%(R%*%beta-r))
# (6) F statistic
(Fstat <- Wald/4)


