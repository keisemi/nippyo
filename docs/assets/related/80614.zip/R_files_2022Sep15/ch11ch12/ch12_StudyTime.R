########################
  # 12章　
########################
# plmパッケージとlmtestパッケージを使います。パッケージをインストールしていない場合には、
# install.packages("plm")　
# install.packages("lmtest")　
# を実行しパッケージをインストールしてください。
library(plm)
library(lmtest)

# データの読み込み
panel <- read.csv("StudyTime_TestScore.csv")
head(panel)



####################
  # 章末問題12.1、章末問12.2 
#################
# 固定効果と時間効果を除去したモデルの推定量
FTE <- plm(TestScore ~ StudyTime, data=panel, index=c("studentID", "testID"), model="within", effect="twoways")
# summary(FTE)
coeftest(FTE, vcov=vcovHC, type="HC2", method=c("arellano"))

# 推定値
(estimates <- round(coeftest(FTE, vcov=vcovHC, type="HC2", method=c("arellano"))[,1],5))
# HC2標準誤差
(stderror <- round(coeftest(FTE, vcov=vcovHC, type="HC2", method=c("arellano"))[,2],4))

# (3) 99%信頼区間
f(2.58)

