########################
		# 11章 
########################
# plmパッケージを使います。plmパッケージをインストールしていない場合には、
# install.packages("plm")　
# を実行しパッケージをインストールしてください。
library(plm)

# データの読み込み
df <- read.csv("testScore.csv")


####################
  # 章末問題11.3 (1)
#################
# プールされたOLS推定量(11.3)式
poolM_Language_a <- lm(Language_a ~ lunch_day+ num_school + num_child_La + FPI, data=df)
summary(poolM_Language_a  )


####################
	# 章末問題11.3 (2)
#################
# 固定効果推定量(11.14)式
fixM_Language_a <- plm(Language_a ~ lunch_day+ num_school + num_child_La + FPI, data=df, effects=c("individual"), index=("Prefecture"), model="within")
summary(fixM_Language_a  )
