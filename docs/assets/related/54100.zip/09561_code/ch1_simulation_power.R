# 統計的仮設検定の方法論：表1.2

rm(list = ls())
set.seed(123)

 # シミュレーション回数
 n <- 10000

 # 検定関数
 phi_1 <- function(x) x > 1.645
 phi_2 <- function(x,u) (u == 1)*(x > 3.09) + (u == 0)*(x > 1.287) 
 
 # n 回分の検定を実施
 thetas <- c(0, 0.5, 1, 2, 3)
 test <- Vectorize(function(theta){
	X <- rnorm(n, mean = theta)
	U <- sample(0:1, n, replace = T)
	c(mean(phi_1(X)), mean(phi_2(X,U)))
	})

 # 結果を出力
 test(thetas)