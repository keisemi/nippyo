# 統計的仮設検定の方法論：表5.1

rm(list = ls())

 # ブートストラップサンプル数
 S <- 1000
 # 検定統計量
 stat1 <- function(x, n, m) sqrt(n) * (mean(x) - m) / sd(x)
 stat2 <- function(x, n, m) sqrt(n) * (mean(x) - m) 

 # 検定を実施
 test <- function(seed, n, m0){
	set.seed(seed)
	X <- rchisq(n, df = 1)

	mat <- matrix(0, S, 2)
	for(s in 1:S){
		id <- sample(1:n, replace = TRUE)
		mat[s, 1] <- stat1(X[id], n, mean(X))
		mat[s, 2] <- stat2(X[id], n, mean(X))
		}

	c1 <- quantile(mat[, 1], c(0.90, 0.95, 0.99))
	c2 <- quantile(mat[, 2], c(0.90, 0.95, 0.99))

	asymp <- stat1(X, n, m0) > c(qnorm(0.90), qnorm(0.95), qnorm(0.99)) 
	boot1 <- stat1(X, n, m0) > c1
	boot2 <- stat2(X, n, m0) > c2

	c(asymp, boot1, boot2)
	}

　# 1000 回分のシミュレーション結果を格納
 run_tests <- function(n, m0values) {
	results <- matrix(0, length(m0values), 9)
	for(j in 1:length(m0values)){
		m0 <- m0values[j]
		res <- matrix(0, 1000, 9)
		for(i in 1:1000){
			res[i, ] <- test(i, n, m0)
			}
		results[j, ] <- colMeans(res)
  		}
  	results
	}

 res_50  <- run_tests(50, c(1, 0.8, 0.7))
 res_100 <- run_tests(100, c(1, 0.8, 0.7))
 res_200 <- run_tests(200, c(1, 0.8, 0.7))

 # 結果を出力
 print(res_50)
 print(res_100)
 print(res_200)
