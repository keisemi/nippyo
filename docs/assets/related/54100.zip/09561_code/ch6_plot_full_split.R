# 統計的仮設検定の方法論：図6.3

rm(list = ls())
set.seed(1)
library(AER)
library(ggplot2)
library(gridExtra)
data("PhDPublications")

find_intervals <- function(data) {
  starts <- which(diff(c(0, data)) == 1)
  ends <- which(diff(c(data, 0)) == -1)
  return(data.frame(start = starts, end = ends))
}
########################

 data <- PhDPublications[PhDPublications$mentor < 40, ]
 Y <- data$articles
 X <- data$mentor
 n <- length(Y)

 # 4 次多項式
 P <- cbind(1, X, X^2, X^3, X^4)
 xseq <- seq(min(X), max(X), 1)
 p <- cbind(1, xseq, xseq^2, xseq^3, xseq^4)

# 完全コンフォーマル予測
　
　judge <- function(x,y){
	Xx <- c(X, x)
	Pp <- cbind(1, Xx, Xx^2, Xx^3, Xx^4)
	Yy <- c(Y, y)
	R  <- abs(lm(Yy ~ Pp - 1)$residual)
	k <- ceiling(0.9 * (n + 1))
	crit <- sort(R)[k]
	R[n+1] <= crit
	}

 yseq <- seq(min(Y), max(Y), 0.5)
 result <- matrix(0, length(xseq), length(yseq))
 for(i in 1:length(xseq)) for(j in 1:length(yseq)) result[i,j] <- judge(xseq[i], yseq[j])

 PI <- matrix(0, length(xseq), 2) 
 for(i in 1:length(xseq)){
	int <- find_intervals(result[i,])
	PI[i,1] <- yseq[int$start]
	PI[i,2] <- yseq[int$end]
	}

# Plot

 df_points <- data.frame(X = X, Y = Y)
 df_lines <- data.frame(xseq = xseq, PI_lower = PI[, 1], PI_upper = PI[, 2])
 p_full <- ggplot() + geom_point(data = df_points, aes(x = X, y = Y)) +
  geom_ribbon(data = df_lines, aes(x = xseq, ymin = PI_lower, ymax = PI_upper), alpha = 0.2, fill = "blue") +
  labs(x = "mentor", y = "articles", title = "完全コンフォーマル予測") +
  theme_minimal()

 y_lim <- range(c(Y, df_lines$PI_lower, df_lines$PI_upper))

# 分割コンフォーマル予測

 n1 <- 500
 n2 <- n - n1
 train <- sample(1:n, n1)
 calib <- setdiff(1:n, train)

 Y1 <- Y[train]
 Y2 <- Y[calib]
 X1 <- X[train]
 X2 <- X[calib]

 P1 <- P[train, ]
 P2 <- P[calib, ]

 reg <- lm(Y1 ~ P1 - 1)
 R2 <- abs(Y2 - P2 %*% reg$coef)
 k <- ceiling(0.9 * (n2 + 1))
 q <- sort(R2)[k]

 mu <- p %*% reg$coef
 PI <- cbind(mu - q, mu + q)

# Plot

 df_points <- data.frame(X = X, Y = Y)
 df_lines <- data.frame(xseq = xseq, mu = mu, PI_lower = PI[, 1], PI_upper = PI[, 2])
 p_split <- ggplot() + geom_point(data = df_points, aes(x = X, y = Y)) +
  geom_line(data = df_lines, aes(x = xseq, y = mu), color = "blue") +
  geom_ribbon(data = df_lines, aes(x = xseq, ymin = PI_lower, ymax = PI_upper), alpha = 0.2, fill = "blue") +
  labs(x = "mentor", y = "articles", title = "分割コンフォーマル予測") +
  theme_minimal()
 
 y_lim <- range(c(y_lim, df_lines$PI_lower, df_lines$PI_upper))
 p_full <- p_full + ylim(y_lim)
 p_split <- p_split + ylim(y_lim)

 grid.arrange(p_full, p_split, nrow = 1)

