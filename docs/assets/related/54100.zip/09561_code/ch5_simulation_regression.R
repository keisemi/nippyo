# 統計的仮設検定の方法論：表5.2

rm(list = ls())
# 計算量が大きいため並列化して処理する
library(parallel)
library(foreach)
library(doParallel)
cl <- makeCluster(detectCores(logical = TRUE) - 2)
registerDoParallel(cl)
##########################

 ns <- c(50, 100, 300)
 dgp1 <- c(1, 2)
 dgp2 <- c(1, 2)

 # ブートストラップサンプル数
 S <- 1000
　# シミュレーション回数
 nrep <- 1000

 for(n in ns){
 for(h in dgp1){
 for(e in dgp2){

 # 検定統計量
 stat <- function(y,x1,x2,b){
	reg  <- lm_robust(y ~ x1 + x2, se_type = "HC0")
	coef <- reg$coefficients[2]
	se   <- reg$std.error[2]
	abs((coef - b)/se)
	}

 sigma <- function(x1,x2) 0.2 + 0.4*x1^2 + 0.4*exp(x2/3)

 res <- foreach(seed = 1:nrep, .packages = c("estimatr"), .combine = rbind) %dopar% {

	set.seed(seed)
	X1 <- rnorm(n)
	X2 <- rnorm(n)
	s <- (h == 1)*1 + (h == 2)*sigma(X1,X2)
	err <- (e == 1)*rnorm(n) + (e == 2)*(rchisq(n, df = 5) - 5)/3
	Y <- 1 + X1 * 0 + X2 + s*err
	ols   <- lm(Y ~ X1 + X2)
	beta  <- ols$coef[2]
	resid <- ols$resid
	pred  <- predict(ols)
	stat0 <- stat(Y,X1,X2,0)

	# PB | RB | WB1 | WB2 

	mat <- matrix(0, S, 4) 
	for(s in 1:S){
		id <- sample(1:n, replace = TRUE)
		W1 <- ifelse(runif(n) < (sqrt(5) - 1)/(2*sqrt(5)), (1 + sqrt(5))/2, (1 - sqrt(5))/2)
		W2 <- sample(c(-1,1), n, replace = TRUE)
		mat[s,1] <- stat(Y[id], X1[id], X2[id], beta)
		mat[s,2] <- stat(pred + resid[id], X1, X2, beta)
		mat[s,3] <- stat(pred + W1 * resid, X1, X2, beta)
		mat[s,4] <- stat(pred + W2 * resid, X1, X2, beta)
		}
	p_crit  <- quantile(mat[,1], c(0.90, 0.95, 0.99))
	r_crit  <- quantile(mat[,2], c(0.90, 0.95, 0.99))
	w_crit1 <- quantile(mat[,3], c(0.90, 0.95, 0.99))
	w_crit2 <- quantile(mat[,4], c(0.90, 0.95, 0.99))

	asymp   <- stat0 > qnorm(c(0.95, 0.975, 0.995)) 
	p_boot  <- stat0 > p_crit
	r_boot  <- stat0 > r_crit
	w_boot1 <- stat0 > w_crit1
	w_boot2 <- stat0 > w_crit2
	c(asymp, p_boot, r_boot, w_boot1, w_boot2)
	}

	# 結果はcsvファイルで出力
	name <- paste("n", n, "hetero", h, "err", e, "csv", sep = ".")
	write.csv(colMeans(res), name, row.names = FALSE)
    	}}}

 stopCluster(cl)
 

