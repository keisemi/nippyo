# 統計的仮設検定の方法論：図6.5

rm(list = ls())
set.seed(1)
library(AER)
library(ggplot2)
library(gridExtra)
library(quantreg)
data("PhDPublications")

find_intervals <- function(data) {
  starts <- which(diff(c(0, data)) == 1)
  ends <- which(diff(c(data, 0)) == -1)
  return(data.frame(start = starts, end = ends))
}
########################

 data <- PhDPublications[PhDPublications$mentor < 40, ]
 Y <- data$articles
 X <- data$mentor
 n <- length(Y)

 # 4 次多項式
 P <- cbind(1, X, X^2, X^3, X^4)
 xseq <- seq(min(X), max(X), 1)
 p <- cbind(1, xseq, xseq^2, xseq^3, xseq^4)

 n1 <- 500
 n2 <- n - n1
 train <- sample(1:n, n1)
 calib <- setdiff(1:n, train)

 Y1 <- Y[train]
 Y2 <- Y[calib]
 X1 <- X[train]
 X2 <- X[calib]

 P1 <- P[train, ]
 P2 <- P[calib, ]

# スケール化残差スコア

 reg <- lm(Y1 ~ P1 - 1)
 V1 <- abs(reg$residual)

 O <- function(param){
	resid <-  V1 - exp(cbind(1, X1) %*% param)
	sum(resid^2)
	}
 A <- optim(c(0,0), O, method = "BFGS")
 
 R2 <- abs(Y2 - P2 %*% reg$coef)
 V2 <- exp(cbind(1, X2) %*% A$par)
 S2 <- R2/V2
 k <- ceiling(0.9 * (n2 + 1))
 q <- sort(S2)[k]

 mu <- p %*% reg$coef
 s <- exp(cbind(1, xseq) %*% A$par)
 PI <- cbind(mu - s*q, mu + s*q)

# Plot

 df_points <- data.frame(X = X, Y = Y)
 df_lines <- data.frame(xseq = xseq, mu = mu, PI_lower = PI[, 1], PI_upper = PI[, 2])
 p_scaled <- ggplot() + geom_point(data = df_points, aes(x = X, y = Y)) +
  geom_line(data = df_lines, aes(x = xseq, y = mu), color = "blue") +
  geom_ribbon(data = df_lines, aes(x = xseq, ymin = PI_lower, ymax = PI_upper), alpha = 0.2, fill = "blue") +
  labs(x = "mentor", y = "articles", title = "スケール化残差スコア") +
  theme_minimal()

 y_lim <- range(c(Y, df_lines$PI_lower, df_lines$PI_upper))

# コンフォーマル分位点回帰

 qr_hi <- rq(Y1 ~ P1 - 1, tau = 0.95)
 qr_lo <- rq(Y1 ~ P1 - 1, tau = 0.05)
 Ehi <- Y2 - P2 %*% qr_hi$coef
 Elo <- P2 %*% qr_lo$coef - Y2
 E <- apply(cbind(Ehi,Elo), 1, max) 
 e <- sort(E)[k]
 PI <- cbind(p %*% qr_lo$coef - e, p %*% qr_hi$coef + e)

# Plot

 df_points <- data.frame(X = X, Y = Y)
 df_lines <- data.frame(xseq = xseq, PI_lower = PI[, 1], PI_upper = PI[, 2])
 p_quant <- ggplot() + geom_point(data = df_points, aes(x = X, y = Y)) +
  geom_ribbon(data = df_lines, aes(x = xseq, ymin = PI_lower, ymax = PI_upper), alpha = 0.2, fill = "blue") +
  labs(x = "mentor", y = "articles", title = "コンフォーマル分位点回帰") +
  theme_minimal()

 y_lim <- range(c(y_lim, df_lines$PI_lower, df_lines$PI_upper))
 p_scaled <- p_scaled + ylim(y_lim)
 p_quant  <- p_quant + ylim(y_lim)

 grid.arrange(p_scaled, p_quant, nrow = 1)

 