# 統計的仮設検定の方法論：表2.4 (DGP 1)

rm(list = ls())
set.seed(123)

 # サンプルサイズ
 n <- 200
 # 処置グループサイズ
 n1 <- 100
 # 潜在結果変数Y(0)
 Y0 <- rnorm(n)
 # 処置効果
 tau <- 0.5

 # 検定統計量
 T1 <- function(d,y) mean(y[d == 1]) - mean(y[d == 0])
 T2 <- function(d,y) sum(d*rank(y))
 T3 <- function(d,y) sum(d*choose(rank(y) - 1, 4))
 T4 <- function(d,y) ks.test(y[d == 1], y[d == 0])$statistic

 # 検定を実施
 simulation <- function(seed, S, b){
	set.seed(seed)
	dd <- c(rep(1,n1), rep(0, n - n1))
	D <- sample(dd)
	Y <- Y0 + b*D*tau
	res <- matrix(0, S, 4)
	for(s in 1:S){
		d <- sample(dd)
		res[s,1] <- T1(d,Y) >= T1(D,Y)
		res[s,2] <- T2(d,Y) >= T2(D,Y)
		res[s,3] <- T3(d,Y) >= T3(D,Y)
		res[s,4] <- T4(d,Y) >= T4(D,Y)
		}
	colMeans(res)
	}

 nrep <- 500
 bb <- c(0,　0.5,　1)
 SS <- c(100,　200,　500)
 res1 <- matrix(0,　length(bb),　length(SS))
 res2 <- matrix(0,　length(bb),　length(SS))
 res3 <- matrix(0,　length(bb),　length(SS))
 res4 <- matrix(0,　length(bb),　length(SS))
 rjct <- matrix(0, nrep, 4)

 for(b in bb) for(S in SS){ 
	for(i in 1:nrep) rjct[i,] <- simulation(i, S, b) <= 0.05
	res1[which(bb == b),which(SS == S)] <- colMeans(rjct)[1]
	res2[which(bb == b),which(SS == S)] <- colMeans(rjct)[2]
	res3[which(bb == b),which(SS == S)] <- colMeans(rjct)[3]
	res4[which(bb == b),which(SS == S)] <- colMeans(rjct)[4]
	}

 res1
 res2
 res3
 res4