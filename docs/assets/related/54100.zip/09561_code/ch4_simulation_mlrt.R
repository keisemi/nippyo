# 統計的仮設検定の方法論：表4.1

rm(list = ls())

 # サンプルサイズ
 n <- 400
 # m1, m2
 m1 <- 2
 m2 <- 1

 # 臨界値
 c10 <- qchisq(0.8,df=1)
 c05 <- qchisq(0.9,df=1)
 c01 <- qchisq(0.98,df=1)

 # 検定を実施
 test <- function(seed, a, C){
	set.seed(seed)
	X1 <- rnorm(n, mean = m1)
	X2 <- rnorm(n, mean = m2)
	b  <- rbinom(prob = a, size = 1, n)
	X  <- (1-b)*X1 + b*X2
 
	LL <- function(p1,p2,p3){
		pr <- pnorm(p3)
		L  <- pr*dnorm(X, mean = p1) + (1 - pr)*dnorm(X, mean = p2)
		sum(log(L)) + C*log(4*pr*(1 - pr))
		}
    
	# 制約付きMLE
	mle0 <- function(theta) -LL(theta,theta,0)
	A0 <- optim(par = m1, mle0, method = "BFGS")
	# 制約なしMLE
	mle1 <- function(theta) -LL(theta[1],theta[2],theta[3])
	A1 <- optim(par = c(m1,m2,0), mle1, method = "BFGS")
    
	2*(A0$value - A1$value) >= c(c10, c05, c01)
	}

 nrep <- 1000
 res <- matrix(0, nrep, 3)
 for(i in 1:nrep) res[i,] <- test(i, 0, 1)
 colMeans(res)

 res <- matrix(0, nrep, 3)
 for(i in 1:nrep) res[i,] <- test(i, 0, 2)
 colMeans(res)

 res <- matrix(0, nrep, 3)
 for(i in 1:nrep) res[i,] <- test(i, 0.1, 1)
 colMeans(res)

 res <- matrix(0, nrep, 3)
 for(i in 1:nrep) res[i,] <- test(i, 0.1, 2)
 colMeans(res)

 res <- matrix(0, nrep, 3)
 for(i in 1:nrep) res[i,] <- test(i, 0.5, 1)
 colMeans(res)

 res <- matrix(0, nrep, 3)
 for(i in 1:nrep) res[i,] <- test(i, 0.5, 2)
 colMeans(res)