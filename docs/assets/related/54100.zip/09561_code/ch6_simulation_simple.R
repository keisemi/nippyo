# 統計的仮設検定の方法論：表6.1

rm(list = ls())

 # 誤差率 
 alpha <- 0.1

 interval <- function(data) {
	starts <- which(diff(c(0, data)) == 1)
	ends <- which(diff(c(data, 0)) == -1)
	return(data.frame(start = starts, end = ends))
	}

　# 整合性スコア
 stat1 <- function(x) abs(x - mean(x))
 stat2 <- function(x){
	dens <- density(x)
 	approx(dens$x, dens$y, xout = x)$y * (-1)
	} 

 # 予測集合の計算
 test <- function(n, m, seed){
	set.seed(seed)
	U <- sample(c(0,1), n, replace = T)
 	X <- U * rnorm(n, mean = -m) + (1 - U) * rnorm(n, mean = m) 

	judge <- function(x){
		aug_data <- c(X, x)
		st1 <- stat1(aug_data)
		st2 <- stat2(aug_data)
		k <- ceiling((1 - alpha)*(n + 1))
		crit1 <- sort(st1)[k]
		crit2 <- sort(st2)[k]
		c(st1[n+1] <= crit1, st2[n+1] <= crit2)
		}

	x_seq <- seq(-m - 3, m + 3, length.out = 200)
	result <- matrix(0, 200, 2)
	for(i in 1:200) result[i,] <- judge(x_seq[i])
	int1 <- interval(result[,1])
	PI1  <- c(x_seq[int1$start], x_seq[int1$end])

	int2 <- interval(result[,2])
	PI21 <- c(x_seq[int2$start[1]], x_seq[int2$end[1]])
	PI22 <- c(x_seq[int2$start[2]], x_seq[int2$end[2]])

	PI_naiv <- quantile(X, c(0.05, 0.95))

	u_new <- sample(c(0,1), 1, replace = T)
	x_new <- u_new * rnorm(1, mean = -m) + (1 - u_new) * rnorm(1, mean = m) 	

	c( # 被覆の判定
	　　PI1[1]  < x_new & x_new < PI1[2],
	  sum(c(PI21[1] < x_new & x_new < PI21[2],  PI22[1] < x_new & x_new < PI22[2]), na.rm = T),
	  PI_naiv[1] < x_new & x_new < PI_naiv[2],
	　　 # 予測集合のサイズ
	  PI1[2] - PI1[1],
	  sum(c(PI22[2] - PI22[1], PI21[2] - PI21[1]), na.rm = T),
	  PI_naiv[2] - PI_naiv[1]
	  )
	}
　
 nrep <- 1000
 run_tests <- function(n, m) {
	mat <- matrix(0,nrep,6)
	for(i in 1:nrep) mat[i,] <- test(n, m, i)
	colMeans(mat)
	}

 results_20_0 <- run_tests(20, 0)
 results_40_0 <- run_tests(40, 0)
 results_20_3 <- run_tests(20, 3)
 results_40_3 <- run_tests(40, 3)

 results_20_0
 results_40_0
 results_20_3
 results_40_3
