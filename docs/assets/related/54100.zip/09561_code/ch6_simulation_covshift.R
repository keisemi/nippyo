# 統計的仮設検定の方法論：表6.2

rm(list = ls())

 test <- function(seed, m, s, n){
	set.seed(seed)
	X <- rnorm(n)
	Y <- 1 + X + X^2 + exp(X/3) * rnorm(n)

	X_test <- rnorm(1, mean = m, sd = s)
	Y_test <- 1 + X_test + X_test^2 + exp(X_test/3) * rnorm(1)

	# データの分割
	n1 <- n / 2; n2 <- n - n1
	train <- sample(1:n, n1)
	calib <- setdiff(1:n, train)
	Yt <- Y[train]
	Yc <- Y[calib]
	Xt <- X[train]
	Xc <- X[calib]

	# 残差スコアの計算
	reg <- lm(Yt ~ poly(Xt, 2, raw = T))
	R <- c(abs(Yc - predict(reg, newdata = data.frame(Xt = Xc))), Inf)
	k <- ceiling(0.9 * (n2 + 1))
	# （重みなし）経験分布関数の 0.9 分位点
	q <- sort(R)[k]

	# 重みの計算
	w <- dnorm(Xc, mean = m, sd = s) / dnorm(Xc)
	w_test <- dnorm(X_test, mean = m, sd = s) / dnorm(X_test)
	pw <- c(w / (sum(w) + w_test), w_test / (sum(w) + w_test))
	# 重み付き経験分布関数の 0.9 分位点
	qw <- min(R[sapply(R, function(r) sum(pw[R <= r])) >= 0.9])

	test_pred <- predict(reg, newdata = data.frame(Xt = X_test))
	abs(Y_test - test_pred) <= c(q, qw)
	}

 nrep <- 1000
 mm <- c(0.5,1,2,3)
 ss <- c(1,2)
 res1 <- matrix(0,length(mm),length(ss))
 res2 <- matrix(0,length(mm),length(ss))

 for(m in mm) for(s in ss){ 
	mat <- matrix(0, nrep, 2)
	for(i in 1:nrep) mat[i,] <- test(i, m, s, 200)
	res1[which(mm == m),which(ss == s)] <- colMeans(mat)[1]
	res2[which(mm == m),which(ss == s)] <- colMeans(mat)[2]
	}

 res1
 res2