# 統計的仮設検定の方法論：表3.1

rm(list = ls())
set.seed(1)

 # サンプルサイズ
 n <- 50
 # n <- 200

 # 共変量の生成（シミュレーション中は固定）
 X  <- rnorm(n)
 Xc <- cbind(1, X)
 M  <- diag(n) - Xc %*% solve(t(Xc) %*% Xc) %*% t(Xc)

 # KS 統計量
 KS <- function(R){
	Ro <- sort(R)
	D_pos <- max(1:n/n - Ro)
	D_neg <- max(Ro - (1:n - 1)/n)
	max(D_pos, D_neg)
	}
 
　# R を計算
 Rfunc <- function(V){
	num <- sqrt(n - 2) * M %*% V
	den <- c(sqrt(t(V) %*% M %*% V))
	pnorm(num / den)
	} 
 
 # p 値を計算
 pval <- function(seed, S, b){
	set.seed(seed)
	Y <- 1 + X + (1 - b)*rnorm(n) + b*rt(n, df = 2)
	u <- lm(Y ~ X)$residual
	s2 <- sum(u^2)/(n - 2)
	R_obs <- pnorm(u/sqrt(s2))
	T_obs <- KS(R_obs)
 
	res <- numeric(S)
	for(s in 1:S){
		vs <- rnorm(n)
		Rs <- Rfunc(vs)
		res[s] <- KS(Rs) >= T_obs
		}
	mean(res)
	}

 nrep <- 500
 bb <- c(0,　0.5,　1)
 SS <- c(100,　200,　500)
 res <- matrix(0,　length(bb),　length(SS))
 rjct <- numeric(nrep)

 for(b in bb) for(S in SS){ 
	for(i in 1:nrep) rjct[i] <- pval(i, S, b) <= 0.05
	res[which(bb == b),which(SS == S)] <- mean(rjct)
	}

 res